#include <pstream.h>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include<iomanip>
using namespace std;
class store
{
public:
	string subject[1000],requester_id[1000],updatetime[1000],id[1000];
};
int main()
{
	cout<<endl<<"welcome to ticket viewer!"<<endl<<endl;
	do {		// view options control
		cout<<"select view options:"<<endl;
		cout<<"press 1 to view all tickets"<<endl;
		cout<<"press 2 to view a ticket"<<endl;
		cout<<"type 'quit' to quit"<<endl<<endl;
		string selection;
		cin>>selection;
		if (selection=="1") // view all tickets
		{
			//use pipe to interface with command prompt
			redi::ipstream countview("curl https://zhenwei.zendesk.com/api/v2/tickets.json -u charleswang0527@gmail.com:yp10889900| jq -r '.'");
			string line;
			store stringstore;	//to store the data of tickets
			int count;	// the number of tickets
			count=0;
			while (getline(countview.out(), line))
			{
				size_t quoteposition;
				string parameter;		// the parameter of each tickets
				quoteposition=line.find("\"");	//the following code is to store data of each parameter
				line.erase(1,quoteposition);
				quoteposition=line.find("\"");
				parameter=line.substr(1,quoteposition-1);
				line.erase(1,quoteposition);
				if ((parameter!="requester_id")&&(parameter!="id"))
				{
					quoteposition=line.find("\"");
					line.erase(1,quoteposition-1);
					line.erase(line.length()-1,1);
				}
				else
				{
					quoteposition=line.find(":");
					line.erase(1,quoteposition+1);
					line.erase(line.length()-1,1);
				}
				if (parameter=="subject")
				{
					count++;
					stringstore.subject[count]=line;
				}
				else if (parameter=="requester_id")
				{
					stringstore.requester_id[count]=line;

				}
				else if (parameter=="updated_at")
				{
					stringstore.updatetime[count]=line;
				}
				else if (parameter=="id")
				{
					stringstore.id[count]=line;
				}
			}
			for (int i=1;i<=count;i++)
				cout<<"The ID."<<setw(25)<<stringstore.id[i]+" ticket with subject"<<setw(95)<<stringstore.subject[i]+" opened by"+stringstore.requester_id[i]+" on"+stringstore.updatetime[i]<<endl<<endl;
		}
		else if (selection=="2")	//view a ticket
		{
			cout<<"please enter ticket ID: ";
			string line,id;
			cin>>id;
			redi::ipstream ticket_view("curl https://zhenwei.zendesk.com/api/v2/tickets/"+id+".json -u charleswang0527@gmail.com:yp10889900| jq -r '.'");
			while (getline(ticket_view.out(), line)) cout<<line<<endl;
			cout<<endl;
		}
		else if (selection=="quit") //quit the ticket viewer
		{
			cout<<endl<<"thank you for using ticket viewer:)"<<endl;
			break;
		}
		else cout<<endl<<"please enter correct parameter (1 ,2 or quit)"<<endl<<endl;
	} while (true);
  	return 0;
}






