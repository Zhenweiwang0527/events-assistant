
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include<iomanip>
using namespace std;
class store //to store the data of each ticket
{
public:
	string subject[1000], requester_id[1000], updatetime[1000], id[1000];
};
int main()
{
	cout << endl << "welcome to ticket viewer!" << endl << endl;
	do {
		cout << "select view options:(then press enter)" << endl;
		cout << "press 1 to view all tickets" << endl;
		cout << "press 2 to view a ticket" << endl;
		cout << "type 'quit' to quit" << endl << endl;
		string selection;	//view option control
		cin >> selection;
		if (selection == "1")	// view all tickets
		{
			FILE *in;
			char buff[512];		//use pipe to interface with command prompt
			store stringstore;
			string line;
			int count;	//the number of tickets
			count = 0;
			in = _popen("curl https://zhenwei.zendesk.com/api/v2/tickets.json -u charleswang0527@gmail.com:yp10889900| jq -r . ", "r");
			while (fgets(buff, sizeof(buff), in)!=NULL)
			{
				size_t quoteposition;		
				string parameter;			// the parameter of each ticket
				line = buff;				// the following code is to store the data of each parameter	
				quoteposition = line.find("\"");
				line.erase(1, quoteposition);
				quoteposition = line.find("\"");
				parameter = line.substr(1, quoteposition - 1);
				line.erase(1, quoteposition);
				if ((parameter != "requester_id") && (parameter != "id"))
				{
					quoteposition = line.find("\"");
					line.erase(1, quoteposition - 1);
					line.erase(line.length() - 1, 1);
				}
				else
				{
					quoteposition = line.find(":");
					line.erase(1, quoteposition + 1);
					line.erase(line.length() - 1, 1);
				}
				if (parameter == "error")	//	handle the unavailable API case
				{
					cout << "the API is unavailable" << endl << endl;
					exit(0);
				}
				if (parameter == "subject")
				{
					count++;
					stringstore.subject[count] = line;
				}
				else if (parameter == "requester_id")
				{
					stringstore.requester_id[count] = line;

				}
				else if (parameter == "updated_at")
				{
					stringstore.updatetime[count] = line;
				}
				else if (parameter == "id")
				{
					stringstore.id[count] = line;
				}
			}
			_pclose(in);	// close pipe
			for (int i = 1; i <= count; i++)	//output the brief information of each ticket
				cout << "The ID."<<setw(25)<<stringstore.id[i-1] + " ticket with subject"  <<setw(95)<< stringstore.subject[i] + " opened by" + stringstore.requester_id[i] + " on" + stringstore.updatetime[i-1] << endl << endl;
		}
		else if (selection == "2")	//view a ticket
		{
			cout << "please enter ticket ID: ";	//use the ID of designated ticket
			FILE *in;							//the following code is to output the detail of each ticket 
			char buff[512],command[512];
			string line,id,temp;
			store stringstore;
			cin >> id;
			temp= "curl https://zhenwei.zendesk.com/api/v2/tickets/"+id+".json -u charleswang0527@gmail.com:yp10889900| jq -r . ";
			for (int i = 0; i <= temp.length(); i++)
			{
				command[i] = temp[i];
			}
			in = _popen(command, "r");
			while (fgets(buff, sizeof(buff), in) != NULL) cout << buff;
			_pclose(in);
			cout << endl;
		}
		else if (selection == "quit") //quit ticket viewer
		{
			cout << endl << "thank you for using ticket viewer:)" << endl;
			break;
		}
		else cout << endl << "please enter correct parameter (1 ,2 or quit)" << endl;
	} while (true);
	return 0;
}






